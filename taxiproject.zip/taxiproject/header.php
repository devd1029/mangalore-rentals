<!DOCTYPE html>
	<html lang="zxx" class="no-js">
	<head>
		<!-- Mobile Specific Meta -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<!-- Favicon-->
		<link ?rel="shortcut icon" href="img/title.png">
		<!-- Author Meta -->
		<meta name="mangalore rentals" content="Mangalore rentals provide car on rent for intercity and outercity ride">
		<!-- Meta Description -->
		<meta name="description" content="Mangalore Rentals offer cab Service for Airpot pickup/drop, Tours and travels across the KARNATAKA GOA KERALA">
		<!-- Meta Keyword -->
		<meta name="keywords" content="Mangalorerentals mangalore rentals">
		<!-- meta character set -->
		<meta charset="UTF-8">
		<!-- Site Title -->
		<title>
		Mangalore Rentals</title>
		
		<link href="https://fonts.googleapis.com/css?family=Poppins:100,200,400,300,500,600,700" rel="stylesheet"> 
			<!--
			CSS
			============================================= -->
			<link rel="stylesheet" href="css/linearicons.css">
			<link rel="stylesheet" href="css/font-awesome.min.css">
			<link rel="stylesheet" href="css/bootstrap.css">
			<link rel="stylesheet" href="css/magnific-popup.css">
			<link rel="stylesheet" href="css/nice-select.css">							
			<link rel="stylesheet" href="css/animate.min.css">
			<link rel="stylesheet" href="css/jquery-ui.css">			
			<link rel="stylesheet" href="css/main.css">
		</head>
		<body>	
		
			  <header id="header">
		  		<div class="header-top">
				</div>
			
			    <div class="container main-menu">
			    	<div class="row align-items-center justify-content-between d-flex">
			    		<a href="index.php"><img src="img/logo/logotext.png" alt="" title="" class="logotext" style="width: 141px;border-radius: 5px;border: 4px double #f3f3f3;"/></a>		
						<nav id="nav-menu-container">
							<ul class="nav-menu">
							  <li class="menu-active"><a href="index.php">Home</a></li>
							  <li><a href="about.php">About</a></li>
							  <li><a href="service.php">Services</a></li>
							  <li><a href="vehicletype.php">Vehicles</a></li>
							   <li><a href="gallery.php">Gallery</a></li> 					  			          	          
							  <li><a href="contact.php">Contact</a></li>
							</ul>
						</nav><!-- #nav-menu-container -->		
			    	</div>
			    </div>
			  </header><!-- #header -->