<?php
	$to = 'rr407213@gmail.com';
    $name = $_POST["name"];
    $email= $_POST["email"];
    $text= $_POST["message"];
    $subject= $_POST["subject"];
    


    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= "From: " . $email . "\r\n"; // Sender's E-mail
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

    $message ='<table style="width:100%">
        <tr>
            <td>'.$name.'  '.$subject.'</td>
        </tr>
        <tr><td>Email: '.$email.'</td></tr>
        <tr><td>phone: '.$subject.'</td></tr>
        <tr><td>Text: '.$text.'</td></tr>
        
    </table>';
	
	if(!$mail->send()){
		$result="Something wrong";
	}else{
		$result="thanks ".$_POST['name']."okay";
	}
	if (@mail($to, $email, $message, $headers))
    {
        echo 'Something wrong';
    }else{
        echo 'thank you '.$_POST['name'].'we will get back to you';
    }

}
	
	
?>