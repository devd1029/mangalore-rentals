<?php include("header.php");?>
			<link rel="stylesheet" href="css/sliderstyle.css">
			<script src="js/sliderindex.js"></script> 	
			</head>
		<body>	
	<!-- start banner Area -->
			<section class="banner-area relative about-banner" id="home">	
				<div class="overlay overlay-bg"></div>
				<div class="container">				
					<div class="row d-flex align-items-center justify-content-center">
						<div class="about-content col-lg-12">
							<h1 class="text-white">
								About Us			
							</h1>	
							<p class="text-white link-nav"><a href="index.html">Home </a>  <span class="lnr lnr-arrow-right"></span>  <a href="gallery.html"> Gallery</a></p>
						</div>	
					</div>
				</div>
			</section>
			<!-- End banner Area -->	

<!--slide end-->

			<!-- Start home-about Area -->
			<section class="home-about-area">
				<div class="container">
					<div class="row align-items-center">
						<div class="col-lg-6  col-sm-12 col-xs-12  about-left">
							<section id="slider" class="container1" style="margin-top: 24px;">
									<ul class="slider-wrapper">
									<li class="current-slide">
										<img src="img/benefits/response.png" title="" alt="">

										<div class="caption">
											<h2 class="slider-title">Quick Response Time</h2>
											<p></p>
										</div>
									</li>

									<li>
										<img src="img/benefits/affort.jpg" title="" alt="">

										<div class="caption">
											<h2 class="slider-title">Affortable Price</h2>
											<p>Best service with less Price</p>
										</div>
									</li>

									<li>
										<img src="img/benefits/holiday.jpg" title="" alt="">

										<div class="caption">
											<h2 class="slider-title">Good Holiday Package</h2>
											<p>Tours accross the karnataka, good holidays package</p>
										</div>
									</li>

									</ul>
									<!-- Sombras -->
									<div class="slider-shadow"></div>
									
									<!-- Controles de Navegacion -->
									<ul id="control-buttons" class="control-buttons"></ul>
								</section>
						</div>
						
						<div class="col-lg-6 about-right   ">
						<div style="background-color: white;
    padding: 5%;
    border-radius: 3PX;    box-shadow: 2px 3px 7px -1px;">
							
							<p>Mangalore Rentals allows Flexible bookings, Easily plan a day out without having to worry for booking. Mangalore Rentals to Book cab immediatelyand also booking cab for future.</p>
							<p>We provide taxi service and travel amenities based on luxury and economic point that suites your budget and we are guarantee that you will truly find our service is convenient more than your expectation. Transport vehicles include Innova, Tavera, Mini bus, Ac tempo traveler, Indica, Swift, Dzire, Etios, logan and Buses with 35 seater and 45 seater, luxury and deluxe coach that suites your convenience.</p>
							We arrange the tours for your holiday leisure and business purposes with a dedicative mind to assist you for your comfort. Our tourist destinations include many attractions in Karnataka and other states such as Kerala, Andhra Pradesh, Tamilnadu, Goa, and Maharashtra.
						</div></div>
					
				</div>	
				</div>	
			</section>
			<!-- End home-about Area -->

		
			<!-- End image-gallery Area -->		

					

			<!-- Start home-calltoaction Area -->
			<section class="home-calltoaction-area relative">
				
  
  <script src='https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.0.7/js/swiper.min.js'></script>

  

    <script  src="js/index.js"></script>
	


			</section>
			<!-- End home-calltoaction Area -->										
		<footer class="footer-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-2 col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>CAR/COACH RENTAL</h6>
								<ul>
									<li><a href="#">Car for Wedding </a></li>
									<li><a href="#">Bus for Wedding </a></li>
									<li><a href="#">Car for Transportation</a></li>
								
								</ul>								
							</div>
						</div>
						<div class="col-lg-2 col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>OUTSTATION TOUR PACKAGES</h6>
								<ul>
									<li><a href="#">Ooty Packages</a></li>
									<li><a href="#">Tirupathi Packages</a></li>
									<li><a href="#">Goa Packages</a></li>
									<li><a href="#">Kerala Packages</a></li>
								</ul>								
							</div>
						</div>
						<div class="col-lg-2 col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>KARNATAKA TOUR PACKAGES</h6>
								<ul>
									<li><a href="#">Coorg Tour Package</a></li>
									<li><a href="#">Subramanya & Dharmatsthala Package</a></li>
									<li><a href="#">North Karnataka Package</a></li>
									<li><a href="#">Chikmangalore Package</a></li>
								</ul>								
							</div>
						</div>												
						<div class="col-lg-2 col-md-6 col-sm-6 social-widget">
							<div class="single-footer-widget">
								<h6>Follow Us</h6>
								<p>Let us be social</p>
								<div class="footer-social d-flex align-items-center">
									<a href="#"><i class="fa fa-facebook"></i></a>
									<a href="#"><i class="fa fa-twitter"></i></a>
									<a href="#"><i class="fa fa-dribbble"></i></a>
									<a href="#"><i class="fa fa-behance"></i></a>
								</div>
							</div>
						</div>							
						<div class="col-lg-4  col-md-6 col-sm-6">
							<div class="single-footer-widget">
								<h6>Newsletter</h6>
								<p>Stay update with our latest</p>
								<div class="" id="mc_embed_signup">
									<form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="form-inline">
										<input class="form-control" name="EMAIL" placeholder="Enter Email" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Enter Email '" required="" type="email">
			                            	<button class="click-btn btn btn-default"><span class="lnr lnr-arrow-right"></span></button>
			                            	<div style="position: absolute; left: -5000px;">
												<input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value="" type="text">
											</div>

										<div class="info"></div>
									</form>
								</div>
							</div>
						</div>	
						<p class="mt-80 mx-auto footer-text col-lg-12">
							<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved 
						</p>											
					</div>
				</div>
				<img class="footer-bottom" src="img/footer-bottom.png" alt="">
			</footer>	
			<!-- End footer Area -->

			<script src="js/vendor/jquery-2.2.4.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
			<script src="js/vendor/bootstrap.min.js"></script>			
			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>
  			<script src="js/easing.min.js"></script>			
			<script src="js/hoverIntent.js"></script>
			<script src="js/superfish.min.js"></script>	
			<script src="js/jquery.ajaxchimp.min.js"></script>
			<script src="js/jquery.magnific-popup.min.js"></script>	
 			<script src="js/jquery-ui.js"></script>								
			<script src="js/jquery.nice-select.min.js"></script>							
			<script src="js/mail-script.js"></script>	
			<script src="js/main.js"></script>	
			<script src="js/sliderindex.js"></script>	
		</body>
	</html>